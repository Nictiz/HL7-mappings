This publication contains some xslt's for converting messages from a relatively simple dataset xml format to a FHIR XML.

Beschikbaarstellen medicatiegevens, only toedieningsafspraak and verstrekking are supported at this point in time (to support the 6.12 verstrekkingenlijst 6.12 to MP 9 use case.

Please refer to the appropriate ReadMe.txt, which can be found in folder: 
- mp\9.0.6\beschikbaarstellen_medicatiegegevens